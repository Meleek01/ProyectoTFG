package com.example.socialgameapp.data.models



// Las dos juntas en el mismo sitio
data class LoginRequest(
    val username: String,
    val password: String
)

data class LoginResponse(
    val token: String?,
    val mensaje: String,
    val success: Boolean
)