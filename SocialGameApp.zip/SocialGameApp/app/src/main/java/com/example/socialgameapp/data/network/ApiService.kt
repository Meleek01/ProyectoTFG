package com.example.socialgameapp.data.network



import com.example.socialgameapp.data.models.LoginRequest
import com.example.socialgameapp.data.models.LoginResponse
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Headers


interface ApiService {
    @Headers("Content-Type: application/json") // Añade esta línea
    @POST("api/auth/login")
    suspend fun login(@Body request: LoginRequest): LoginResponse
}