package com.example.socialgameapp.viewmodel

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.socialgameapp.data.repository.AuthRepository
import kotlinx.coroutines.launch

class LoginViewModel : ViewModel() {
    private val repository = AuthRepository()

    var usuario by mutableStateOf("")
    var password by mutableStateOf("")
    var isLoading by mutableStateOf(false)
    var mensajeResultado by mutableStateOf("")

    fun login() {
        if (usuario.isBlank() || password.isBlank()) {
            mensajeResultado = "Debes rellenar todos los campos"
            return
        }

        viewModelScope.launch {
            isLoading = true
            mensajeResultado = "Conectando con Render..."
            val response = repository.loginUser(usuario, password)
            isLoading = false

            if (response.success) {
                mensajeResultado = "¡Login Correcto! Bienvenido."
            } else {
                mensajeResultado = response.mensaje
            }
        }
    }
}