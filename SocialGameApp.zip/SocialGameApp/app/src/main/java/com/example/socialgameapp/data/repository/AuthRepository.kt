package com.example.socialgameapp.data.repository

import com.example.socialgameapp.data.network.RetrofitClient
import com.example.socialgameapp.data.models.LoginRequest
import com.example.socialgameapp.data.models.LoginResponse

class AuthRepository {
    // Esto es lo que te faltaba y por eso 'api' salía en rojo
    private val api = RetrofitClient.instance

    suspend fun loginUser(usuario: String, pass: String): LoginResponse {
        return try {
            // Enviamos 'usuario' de la UI al campo 'username' que espera el servidor
            api.login(LoginRequest(username = usuario, password = pass))
        } catch (e: Exception) {
            LoginResponse(
                token = null,
                mensaje = "Error de conexión: ${e.message}",
                success = false
            )
        }
    }
}